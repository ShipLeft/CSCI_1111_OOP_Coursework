package E6_20;
import java.util.Scanner;
/**
 * <h1>Exercise 6_20</h1>
 * 
 * <p>This class will determine how many characters and letters are in a string.</p>
 * 
 * <p>Created: 10/12/2021
 * 
 * @author Rhett Boatright
 */
public class Exercise06_20 {
	/**
	 * This method will determine variables to be used, gather user input, and print results.
	 * 
	 * @param args (String; placeholder in the main method.)
	 * @param s (String; the string that the user will input.)
	 */
	public static void main(String[] args) {
		Scanner string = new Scanner(System.in);
		
		//Create variables for the program.
		String s = "string";
		
		//Ask user to input String.
		while(true) {
		System.out.println("Enter a string: ");
		s = string.nextLine();
		System.out.println("There are " + countLetters(s) + " letters in " + s + ".");
		}
	}
	
	//Create method for counting in the string
	/**
	 * This method will determine how many characters and letters are in the string.
	 * 
	 * @param s (String; variable from the main method.)
	 * @param count (int; the count of the characters in the string.)
	 * @param a (char; used to check if the current character is a letter or not.)
	 * @param i (int; used to create a for loop.)
	 * @return letter (int; the count of the letters in the string.)
	 */
	public static int countLetters(String s){
		int count = 0, letter = 0;
		char a;
		
		//Create for loop for the method to count the letters.
		for(int i = 0; i < s.length(); i++) {
			count ++;
			a = s.charAt(i);
			if(Character.isLetter(a) == true) {
				letter++;
			}
		}
		System.out.println("There are " + count + " characters in " + s + ".");
		return letter;
	}
}
