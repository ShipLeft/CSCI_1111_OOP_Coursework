package E06_18;

import java.util.Scanner;
/**
 * <h1>Exercise 6_18</h1>
 * 
 * <p>This class will determine if a password is valid or not.</p>
 * 
 * <p>Created: 10/12/2021 </p>
 * 
 * @author Rhett Boatright
 */
public class Exercise06_18 {
	/**
	 * This method will determine variables to be used in the program,
	 * take user inputs, and print out the results.
	 * 
	 * @param args (String; placeholder of the main method.
	 * @param s (String; password that the user will input.
	 */
	public static void main(String[] args) {
		Scanner pass = new Scanner(System.in);//Import the scanner into the code.
		
		//Create variables for the program.
		String s = "string";
		
		//Ask user to input password.
		while(true) {
			System.out.println("Enter a password: ");
			s = pass.nextLine();
			if(isValid(s) == true) {
				System.out.println("Valid Password\n\n");
			}
			else if(isValid(s) == false){
				System.out.println("Invalid Password\n\n");
			}
		}
			
	}
	
	//Create method for checking if the password is valid.
	/**
	 * This method will determine if the password meets all of the criteria.
	 * 
	 * @param s (String; input password from the main method.)
	 * @param a (char; value of the character being checked for number or letter.)
	 * @param count (int; amount of characters that are numbers or letters.)
	 * @param digit (int; amount of characters that are numbers
	 * @return check (boolean; holds the value of the password being valid or not.)
	 */
	public static boolean isValid(String s) {
		
		//Create variables to be used in this method.
		boolean check = true;
		char a;
		int count = 0, digit = 0;
		
		//Create for loop to check the password.
		for(int i = 0; i < s.length(); i++) {
			a = s.charAt(i);
			if(Character.isLetterOrDigit(a) == true) {
				count++;
				if(Character.isDigit(a)) {
					digit++;
				}
		}
			else {
				check = false;
			}
			
		
		}
		if(check != false && count >= 8 && digit >= 2) {
			check = true;
		}
		else {
			check = false;
		}
		return check;
	}
}
