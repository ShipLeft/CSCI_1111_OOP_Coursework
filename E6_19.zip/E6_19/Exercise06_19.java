package E6_19;

import java.text.DecimalFormat;
import java.util.Scanner;
/**
 * <h1>Exercise 6_19</h1>
 *<p> This class will determine whether or not a triangle
 *is valid and if it is, will return the area.</p>
 * 
 * <p> Created: 10/12/2021
 * 
 * @author Rhett Boatright
 */
public class Exercise06_19 {
	/**
	 * This method will determine variables and collect the input
	 * as well as call upon the other methods.
	 * 
	 * @param args (String; is the placeholder for the main method.)
	 * @param side1 (double; is the first side inputed by the user.)
	 * @param side2 (double; is the second side inputed by the user.)
	 * @param side3 (double; is the third side inputed by the user.)
	 */
	public static void main(String[] args){
		
		//Import Scanner
		Scanner triangle = new Scanner(System.in);
		
		//Create Variables for the program
		Double side1 = 0.0, side2 = 0.0, side3 = 0.0;
		
		//Ask user for side inputs
		System.out.println("Enter the length of the 3 sides "
				+ "of the triangle separated by a space:");
			side1 = triangle.nextDouble();
			side2 = triangle.nextDouble();
			side3 = triangle.nextDouble();
			
			//Create an if else for printing result.
			if(isValid(side1, side2, side3) == true) {
				area(side1, side2, side3);
			}
			else {
				System.out.println("That is not a valid triangle.\n\n");
			}
		
		
	}
	
	//Return true if the sum of every two sides is greater than the third side.
	/**
	 * This method determines whether the triangle is valid or not.
	 * 
	 * @param side1 (double; input from main method.)
	 * @param side2 (double; input from main method.)
	 * @param side3 (double; input from main method.)
	 * @return result (boolean; changes depending on triangle validity.)
	 */
	public static boolean isValid(double side1, double side2, double side3) {
		boolean result = false;
		
		//Create if statement to check if triangle meets requirements.
		if((side1 + side2) > side3) {
			if((side1 + side3) > side2) {
				if((side2 + side3) > side1) {
					result = true;
				}
				else {
					result = false;
				}
			}
			else {
				result = false;
			}
		}
		else {
			result = false;
		}
		return result;
		
	}
	
	//Return the area of the triangle
	/**
	 * This method will print the area and sides back to the user.
	 * 
	 * @param side1 (double; input from main method.)
	 * @param side2 (double; input from main method.)
	 * @param side3 (double; input from main method.)
	 * @param p (double; perimeter of triangle using the sides)
	 * @return a (double; area of triangle using the sides and perimeter.)
	 */
	public static double area(double side1, double side2, double side3) {
		
		//Create equations for perimeter and for area
		double p = (side1 + side2 + side3)/2;
		double a = Math.sqrt(p * (p - side1) * (p - side2) * (p - side3));
		
		//Create decimal format
		DecimalFormat decimal = new DecimalFormat("0.0");
		
		//Print out the sides and the area
		System.out.println("Side 1: " + side1);
		System.out.println("Side 2: " + side2);
		System.out.println("Side 3: " + side3);
		System.out.println("Area:   " + decimal.format(a));
		
		return a;
	}
}
